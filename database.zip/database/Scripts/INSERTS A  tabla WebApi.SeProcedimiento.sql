USE [INTERFACE]; 
GO

-- Insertar m�ltiples registros con verificaci�n previa
IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/obtener-url-documentos')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha, ModificaUsuario, ModificaFecha)
    VALUES 
    (51, 'credito-web/obtener-url-documentos', 'Cr�dito - Obtener los documentos a firmar por SignBox', 1, 0, 'WebApi.spObtenerDocumentosParaFirmaElectronica', 1, 1, 0, 0, 'ADMIN', '2025-07-22 00:00:00.000', 'ADMIN', '2025-07-24 11:50:58.007')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/firmado-signbox')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (52, 'credito-web/firmado-signbox', 'Cr�dito - Cambiar el estado del documento a firmado por SignBox', 1, 0, 'WebApi.spCambiarEstadoFirmadoSignBox', 1, 1, 0, 0, 'ADMIN', '2025-07-25 16:36:36.840')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/error-firma-signbox')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (53, 'credito-web/error-firma-signbox', 'Cr�dito - Cambiar el estado de la firma de SignBox a error', 1, 0, 'WebApi.spCambiarEstadoFirmaErrorSignBox', 1, 1, 0, 0, 'ADMIN', '2025-07-25 16:52:21.443')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/obtener-lotes-firmar-OnBoarding')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (54, 'credito-web/obtener-lotes-firmar-OnBoarding', 'Cr�dito - Obtener la informaci�n de los lotes y solicitud que se debe intentar firmar por OnBoarding', 1, 0, 'WebApi.spObtenerLotesParaFirmaOnBoarding', 1, 1, 0, 0, 'ADMIN', '2025-07-28 10:34:58.497')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/obtener-info-solicitante-credito')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (55, 'credito-web/obtener-info-solicitante-credito', 'Cr�dito - Obtener la informaci�n del solicitante de cr�dito para parametrizar la petici�n OnBoarding', 1, 0, 'WebApi.spObtenerInfoSolicitanteCredito', 1, 1, 0, 0, 'ADMIN', '2025-07-28 12:13:00.887')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/enviado-onboarding')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (57, 'credito-web/enviado-onboarding', 'Cr�dito - Cambiar a estado Enviado el lote de documentos enviados por OnBoarding', 1, 0, 'WebApi.spCambiarEstadoEnviadoOnBoarding', 1, 1, 0, 0, 'ADMIN', '2025-07-28 16:07:06.600')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/error-firma-onboarding')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (58, 'credito-web/error-firma-onboarding', 'Cr�dito - Cambiar a estado Error el lote de documentos enviados por OnBoarding', 1, 0, 'WebApi.spCambiarEstadoFirmaErrorOnBoarding', 1, 1, 0, 0, 'ADMIN', '2025-07-28 16:20:29.733')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/obtener-lotes-enviados-onboarding')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (59, 'credito-web/obtener-lotes-enviados-onboarding', 'Cr�dito - Obtener los lotes enviados por OnBoarding para revisar el estado de la firma', 1, 0, 'WebApi.spObtenerLotesEnviadosOnBoarding', 1, 1, 0, 0, 'ADMIN', '2025-07-28 17:40:51.110')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/cambio-estado-firma-onboarding')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (60, 'credito-web/cambio-estado-firma-onboarding', 'Cr�dito - Cambiar el estado de la firma seg�n la ruta que se encuentra el usuario en el OnBoarding', 1, 0, 'WebApi.spCambiarEstadoFirmaOnBoarding', 1, 1, 0, 0, 'ADMIN', '2025-07-28 21:28:51.220')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/obtener-lotes-guardar-documentos')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (61, 'credito-web/obtener-lotes-guardar-documentos', 'Cr�dito - Obtener los lotes para guardar los URLs donde est� cada documento firmado por el OnBoarding', 1, 0, 'WebApi.spObtenerLotesParaGuardarDocumentosFirmados', 1, 1, 0, 0, 'ADMIN', '2025-07-29 10:02:13.163')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/guardar-documentos-firmados-por-lote')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (62, 'credito-web/guardar-documentos-firmados-por-lote', 'Cr�dito - Guardar los documentos firmados seg�n su solicitud y c�digo de documento seg�n la informaci�n del lote', 1, 0, 'WebApi.spGuardarDocumentosFirmadosPorLote', 1, 1, 0, 0, 'ADMIN', '2025-07-29 10:55:46.327')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/insertar-registros_firmaElectronica')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (63, 'credito-web/insertar-registros_firmaElectronica', 'Cr�dito - Guardar los registros en la tabla encargada de auditar todo el proceso de la firma electr�nica', 1, 0, 'WebApi.spInsertarRegistrosFirmaElectronica', 1, 1, 0, 0, 'ADMIN', '2025-07-29 12:58:04.480')
END

IF NOT EXISTS (SELECT 1 FROM WebApi.SeProcedimiento WHERE Codigo = 'credito-web/obtener-docs-firmar-SignBox')
BEGIN
    INSERT INTO WebApi.SeProcedimiento 
    (Id, Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    (64, 'credito-web/obtener-docs-firmar-SignBox', 'Cr�dito - Obtener los documentos a firmar por SignBox', 1, 0, 'WebApi.spObtenerDocumentosFirmarSignBox', 1, 1, 0, 0, 'ADMIN', '2025-07-29 13:14:23.673')


    INSERT INTO WebApi.SeProcedimiento 
    (Codigo, Nombre, Activo, Modulo, NombreProcedimiento, GuardarRequest, GuardarResult, EncriptarResult, EncriptarRequest, CreacionUsuario, CreacionFecha)
    VALUES 
    ('parametros/obtener-info-firm-coop', 'Parametros - Obtener la informaci�n del firmante de la cooperativa para firma SignBox', 1, 0,
	'WebApi.spObtenerInfoFirmanteCoop', 1, 1, 0, 0, 'ADMIN', '2025-07-29 13:14:23.673')
END

